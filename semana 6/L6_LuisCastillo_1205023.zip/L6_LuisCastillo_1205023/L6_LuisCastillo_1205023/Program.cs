﻿// See https://aka.ms/new-console-template for more information

Console.WriteLine("------------------EJERCICIO 1------------------");
Console.WriteLine("------------OPERACIONES ARIMETICAS-------------");
Console.WriteLine(); //ESPACIOS
Console.WriteLine("Ingrese número 1");
double N1 = Convert.ToDouble(Console.ReadLine());
Console.WriteLine(); //ESPACIOS
Console.WriteLine("Ingrese número 2");
double N2 = Convert.ToDouble(Console.ReadLine());
Console.WriteLine(); //ESPACIOS
double Suma = N1 + N2;
double Resta = N1 - N2;
double Multiplicacion = N1 * N2;
double Division = N1 / N2;
int DIV = (int) (N1 / N2);
double MOD = N1 % N2;
Console.WriteLine("------------------RESULTADOS------------------");
Console.WriteLine("Suma:\n" + N1 + " MAS " + N2 +" = " + Suma);
Console.WriteLine("Resta:\n" + N1 + " MENOS " + N2 + " = " + Resta);
Console.WriteLine("Multiplicacion:\n" + N1 + " POR " + N2 + " = " + Multiplicacion);
Console.WriteLine("Division:\n" + N1 + " DIVIDIDO " + N2 + " = " + Division);
Console.WriteLine("DIV:\n" + N1 + " DIV " + N2 + " = " + DIV);
Console.WriteLine("MOD:\n" + N1 + " MOD " + N2 + " = " + MOD);
Console.WriteLine(); //ESPACIOS

Console.WriteLine("------------------EJERCICIO 2------------------");
Console.WriteLine("------------OPERACIONES BOOLEANAS-------------");
Console.WriteLine(); //ESPACIOS

if (N1 == N2)
{
    Console.WriteLine("El valor de número 1 y número 2 son iguales");

}
else if (N1 < N2)
{
    Console.WriteLine("El número 1 es menor que número 2");
}
else
{
    Console.WriteLine("El número 1 es mayor que número 2");
}

Console.WriteLine(); //ESPACIOS

Console.WriteLine("------------------EJERCICIO 3------------------");
Console.WriteLine("------------JERARQUIA OPERACIONES-------------");
Console.WriteLine(); //ESPACIOS
Console.WriteLine("Ingrese número 1");
double a = Convert.ToDouble(Console.ReadLine());
Console.WriteLine(); //ESPACIOS
Console.WriteLine("Ingrese número 2");
double b = Convert.ToDouble(Console.ReadLine());
Console.WriteLine(); //ESPACIOS
Console.WriteLine("Ingrese número 3");
double c = Convert.ToDouble(Console.ReadLine());
Console.WriteLine(); //ESPACIOS

double OPRCN1 = a * b + c;
double OPRCN2 = a * (b + c);
double OPRCN3 = a / (b * c);
double OPRCN4 = (3 * a) + (2 * b) / Math.Pow(c, 2);

Console.WriteLine("------------------RESULTADOS------------------");
Console.WriteLine(); //ESPACIOS

Console.WriteLine("El resultado de la operacios a ∗ b + c = " + OPRCN1);
Console.WriteLine("El resultado de la operacios a * (b + c) = " + OPRCN2);
Console.WriteLine("El resultado de la operacios a / b * c = " + OPRCN3);
Console.WriteLine("El resultado de la operacios 3a + 2b / c^2 = " + OPRCN4);
Console.WriteLine(); //ESPACIOS

Console.WriteLine("------------------EJERCICIO 4------------------");
Console.WriteLine("------------FORMULA CUADRATICA-------------");
Console.WriteLine(); //ESPACIOS

double Discri = Math.Pow(b, 2) - (4 * a * c);

if (a == 0)
{
    Console.WriteLine("El valor de a no puede ser 0");
}
else if  (Discri <= 0)
{
    Console.WriteLine("Los valores de b y c dan un número negativo");
}
else
{
    double x1 = (-b + Math.Sqrt(Discri)) / (2 * a);
    double x2 = (-b - Math.Sqrt(Discri)) / (2 * a);
    Console.WriteLine("El resultado es: \n X1 = " + x1 + "\n  X2 = " + x2);
}





Console.ReadKey();








