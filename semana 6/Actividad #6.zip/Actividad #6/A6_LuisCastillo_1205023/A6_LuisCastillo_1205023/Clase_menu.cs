﻿using System.Runtime.InteropServices;

namespace A6_LuisCastillo_1205023
{
    class Clase_menu
    {
        static void Main(string[] args)
        {
            Console.WriteLine("-------------PROGRAMA DE RECORDATORIO DE TAREAS-------------");
            Console.WriteLine();
            Console.WriteLine("-------------Menu de opcion de recordatorio-------------");
            Console.WriteLine("Seleccione alguina opicion");
            Console.WriteLine();
            Console.WriteLine("1. CORREO");
            Console.WriteLine("2. QUE CURSOS QUIERE QUE NOTIFIQUE ");
            Console.WriteLine("3. HORARIO DE RECORDATORIO");
            int opc = Convert.ToInt32(Console.ReadLine());

            switch (opc)
            {
                case 1:
                    Console.WriteLine("Selecciono la opcion: " + opc + "CORREO");
                    break;
                case 2:
                    Console.WriteLine("Selecciono la opcion: " + opc + "QUE CURSOS QUIERE QUE NOTIFIQUE");
                    break;
                case 3:
                    Console.WriteLine("Selecciono la opcion: " + opc + "HORARIO DE RECORDATORIO");
                    break;
                default:
                    Console.WriteLine("Selecciono una opcion invalida");
                    break;


            }
            


            Console.ReadKey();

            
        }
    }
}