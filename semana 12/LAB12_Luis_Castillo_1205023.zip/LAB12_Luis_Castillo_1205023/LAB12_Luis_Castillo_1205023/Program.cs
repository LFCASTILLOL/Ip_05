﻿class Circulo
{
    private double radio;

    public Circulo(double radio)
    {
        this.radio = radio;
    }

    private double ObtPerimetro()
    {
        return 2 * Math.PI * radio;
    }

    private double ObtArea()
    {
        return Math.PI * radio * radio;
    }

    private double ObtVolumen()
    {
        return (4.0 / 3.0) * Math.PI * Math.Pow(radio, 3);
    }

    public void Geometria(ref double Perimetro, ref double Area, ref double Volumen)
    {
        Perimetro = ObtPerimetro();
        Area = ObtArea();
        Volumen = ObtVolumen();
    }
}

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ingrese el radio del círculo: ");
        double radio = Convert.ToDouble(Console.ReadLine());

        Circulo objCirculo = new Circulo(radio);

        double perimetro = 0, area = 0, volumen = 0;
        objCirculo.Geometria(ref perimetro, ref area, ref volumen);

        Console.WriteLine("Perímetro del círculo: " + perimetro);
        Console.WriteLine("Área del círculo: " + area);
        Console.WriteLine("Volumen de la esfera: " + volumen);
    }
}
