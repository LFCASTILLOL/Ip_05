﻿namespace T1_Luis_Castillo_1205023
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mi segundo programa ");
            string sNombre, sEdad, sCarrera, sCarne;

            Console.WriteLine("Ingrese su Nombre:");
            sNombre = Console.ReadLine();

            Console.WriteLine("Ingrese su edad:");
            sEdad = Console.ReadLine();

            Console.WriteLine("Ingrese su carrera:");
            sCarrera = Console.ReadLine();

            Console.WriteLine("Ingrese su numero de carnet:");
            sCarne = Console.ReadLine();

            Console.WriteLine("Mi segundo programa ");
            Console.WriteLine("Nombre:" + sNombre);
            Console.WriteLine("Edad:" + sEdad);
            Console.WriteLine("Carrera:" + sCarrera);
            Console.WriteLine("Carne:" + sCarne);


            Console.WriteLine("Soy " + sNombre + " tengo, " + sEdad + " años y estudio la carrera de " + sCarrera);
            Console.WriteLine("Mi número de carné es; " + sCarne);
            Console.ReadKey();

        }
    }
}