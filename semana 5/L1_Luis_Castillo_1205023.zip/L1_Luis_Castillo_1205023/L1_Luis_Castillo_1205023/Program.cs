﻿namespace L1_Luis_Castillo_1205023
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hola Mundo soy Luis Castillo");
            Console.WriteLine("Hola Mundo");
            Console.WriteLine("Soy Luis");
            Console.WriteLine("----------------------------------------------------------");

            // Usando Write y su diferencia 
            Console.Write("Hola mundo");
            Console.Write("Soy Luis");

            // PEDIR UN NOMBRE
            Console.WriteLine("----------------------------------------------------------");
            Console.WriteLine("Ingrese su nombre:");
            string Nombre = Console.ReadLine();

            Console.WriteLine("Hola Mundo");
            Console.WriteLine("Mi nombre es " + Nombre);
            Console.WriteLine("----------------------------------------------------------");

            // Solo con Write
            Console.Write("Hola Mundo");
            Console.Write("Mi nombre es " + Nombre);
            Console.ReadKey();

        }
    }
}