﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("--------------EJERCICIO 1--------------");
Console.WriteLine();
Console.WriteLine("Ingrese un numero entero: ");
int N1 = Convert.ToInt32(Console.ReadLine());
Console.WriteLine();
Console.WriteLine("--------------RESULTADO--------------");

if (N1 < 0)
{
    Console.WriteLine("NUMERO ES NEGATIVO " + N1);
}
else if (N1 > 0)
{
    Console.WriteLine("NUMERO ES POSITIVO " + N1);
}
else
{
    Console.WriteLine("NUMERO ES CERO " + N1);
}
Console.WriteLine();
Console.WriteLine("--------------EJERCICIO 2--------------");
Console.WriteLine("Ingrese el número del día de la semana");
int opc = Convert.ToInt32(Console.ReadLine());
Console.WriteLine();

switch (opc)
{
    case 1:
        Console.WriteLine("El día es lunes");
    break;
    case 2:
            Console.WriteLine("El dia es martes");
    break;
    case 3:
        Console.WriteLine("El dia es miercoles");
    break;
        case 4:
            Console.WriteLine("El dia es jueves");
        break;

    case 5:
        Console.WriteLine("El dia es viernes");
    break;
        case 6:
            Console.WriteLine("El dia es sabado");
        break;
    case 7:
        Console.WriteLine("El dia es domingo");
    break;
    default:
        
            Console.WriteLine("Error: El número a ingresar debe estar contenido entre 1 y 7");
        break;
}

Console.ReadKey();