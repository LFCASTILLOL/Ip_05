﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_final_pruebas
{
    public class MENUPRIN
    {
      public static void Menus()
        {
            bool salir = false;
            while (!salir)
            {
                Console.Clear();
                Console.WriteLine("Ingrese que menu quiere ingresar:");
                Console.WriteLine("1. MENÚ DE INFORMACIÓN BÁSICA\n2. DETALLES DE LA TAREA/EXAMEN/PROYECTO" +
                    "\n3. OPCIONES DE NOTIFICACIÓN\n4. OPCIONES ADICIONALES\n5. INFORMACIÓN DE CONTACTO DE EMERGENCIA" +
                    "\n6. CONFIGURACIÓN DE PREFERENCIAS\n 7.Salir");
                int opcM = Convert.ToInt32(Console.ReadLine());

                switch (opcM)
                {
                    case 1:
                        bool Rep1 = true;
                        while (Rep1)
                        {
                            Console.WriteLine("-----------------------------MENÚ DE INFORMACIÓN BÁSICA-----------------------------");
                            Console.WriteLine("1. Nombre completo");
                            string nombre = Convert.ToString(Console.ReadLine());
                            Console.WriteLine("2. Número de carnet");
                            int carnet = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("3. Carrera");
                            string carrera = Convert.ToString(Console.ReadLine());

                            Console.WriteLine($"Nombre: {nombre}, Carnet: {carnet} y Carrera {carrera}");
                            
                            Console.WriteLine("¿Desea repetir el menú? (Sí/No): ");
                            string resp1 = Console.ReadLine();

                            if (!resp1.Equals("Sí", StringComparison.OrdinalIgnoreCase))
                            {
                                Rep1 = false;
                            }

                            Console.WriteLine("Menu 1 finalizado, precione enter para continuar.");
                            Console.ReadKey();
                        }
                        
                        break;
                    case 2:
                        bool Rep2 = true;
                        while (Rep2)
                        {
                            Console.Clear();
                            Console.WriteLine("-----------------------------DETALLES DE LA TAREA/EXAMEN/PROYECTO-----------------------------");

                            Console.WriteLine("1. Título de la tarea/examen/proyecto:");
                            string titulo = Convert.ToString(Console.ReadLine());
                            Console.WriteLine("2. Descripción detallada:");
                            string desc = Convert.ToString(Console.ReadLine());
                            Console.WriteLine("3. Fecha y hora de vencimiento:");
                            string fecha = Convert.ToString(Console.ReadLine());
                            Console.WriteLine("4. Prioridad (alta, media, baja):");
                            string prio = Convert.ToString(Console.ReadLine());
                            Console.WriteLine("5. Tipo (tarea, examen, proyecto, otro):");
                            string tipo = Convert.ToString(Console.ReadLine());
                            Console.WriteLine("6. Materia o asignatura:");
                            string materia = Convert.ToString(Console.ReadLine());

                            Console.WriteLine($"Titulo: {titulo} \n Descripccion de la tarea: {desc} \n Fecha y hora: {fecha} \n Priordidad: {prio}" +
                                $"Tipo: {tipo} \n Materia: {materia}");

                            Console.WriteLine("¿Desea repetir el menú? (Sí/No): ");
                            string resp2 = Console.ReadLine();

                            if (!resp2.Equals("Sí", StringComparison.OrdinalIgnoreCase))
                            {
                                Rep2 = false;
                            }
                            Console.WriteLine("Menu 2 finalizado, precione enter para continuar.");
                            Console.ReadKey();
                        }

                            break;
                        case 3:
                        bool Rep3 = true;
                        while (Rep3)
                        {

                            Console.Clear();
                            Console.WriteLine("-----------------------------OPCIONES DE NOTIFICACIÓN-----------------------------");

                            Console.WriteLine("1. Cuántos días antes de la fecha de vencimiento desean recibir notificaciones: ");
                            int dias = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("2. Preferencia de notificación (correo electrónico, notificación en la aplicación, mensaje de texto, otro): ");
                            string notificacion = Convert.ToString(Console.ReadLine());
                            Console.WriteLine("3. ¿Deseas recordatorios diarios hasta la fecha de vencimiento?: si = true y no = false");
                            bool diario = Convert.ToBoolean(Console.ReadLine());

                            Console.WriteLine($"Los dias previos que se enviara el correo son: {dias}, la notificaciones seran por: {notificacion}" +
                                $" y los recordatorios {diario} seran enviados.");

                            Console.WriteLine("¿Desea repetir el menú? (Sí/No): ");
                            string resp3 = Console.ReadLine();

                            if (!resp3.Equals("Sí", StringComparison.OrdinalIgnoreCase))
                            {
                                Rep3 = false;
                            }

                            Console.WriteLine("Menu 3 finalizado, precione enter para continuar.");
                            Console.ReadKey();
                        }


                        break;
                    case 4:
                        bool Rep4 = true;
                        while (Rep4)
                        {

                            Console.Clear();
                            Console.WriteLine("-----------------------------OPCIONES ADICIONALES-----------------------------");

                            Console.WriteLine("1. Adjuntos (posibilidad de cargar archivos relacionados): si = true y no = false ");
                            bool carga = Convert.ToBoolean(Console.ReadLine());
                            Console.WriteLine("2. Estado de finalización (marcar como completado cuando termine): si = true y no = false ");
                            bool finalizacion = Convert.ToBoolean(Console.ReadLine());
                            Console.WriteLine("3. Notas adicionales: si = true y no = false ");
                            bool notas = Convert.ToBoolean(Console.ReadLine());
                            Console.WriteLine("4. Categorización o etiquetas personalizables: si = true y no = false ");
                            bool etiquetas = Convert.ToBoolean(Console.ReadLine());

                            Console.WriteLine($"Archivos: {carga}, Estado de finalización: {finalizacion} y Notas adicionales: {notas}" +
                                $"Categorización o etiqueta: {etiquetas}");

                            Console.WriteLine("¿Desea repetir el menú? (Sí/No): ");
                            string resp4 = Console.ReadLine();

                            if (!resp4.Equals("Sí", StringComparison.OrdinalIgnoreCase))
                            {
                                Rep4 = false;
                            }

                            Console.WriteLine("Menu 4 finalizado, precione enter para continuar.");
                            Console.ReadKey();

                        }
                        break;
                    case 5:
                        bool Rep5 = true;
                        while (Rep5)
                        {
                            Console.Clear();
                            Console.WriteLine("-----------------------------INFORMACIÓN DE CONTACTO DE EMERGENCIA-----------------------------");

                            Console.WriteLine("1. Nombre de un contacto de emergencia: ");
                            string nombreE = Convert.ToString(Console.ReadLine());

                            Console.WriteLine("2. Número de teléfono de contacto de emergencia: ");
                            string telefono = Convert.ToString(Console.ReadLine());

                            Console.WriteLine($"Nombre de un contacto de emergencia: {nombreE} y Número de teléfono de contacto de emergencia: {telefono} ");

                            Console.WriteLine("¿Desea repetir el menú? (Sí/No): ");
                            string resp5 = Console.ReadLine();

                            if (!resp5.Equals("Sí", StringComparison.OrdinalIgnoreCase))
                            {
                                Rep5 = false;
                            }

                            Console.WriteLine("Menu 7 finalizado, precione enter para continuar.");
                            Console.ReadKey();
                        }
                        break;


                    case 6:
                        bool Rep6 = true;
                        while (Rep6)
                        {

                            Console.Clear();
                            Console.WriteLine("-----------------------------CONFIGURACIÓN DE PREFERENCIAS-----------------------------");

                            Console.WriteLine("1. Quiere cambiar la configuración de notificación: ");
                            bool Configuaracion = Convert.ToBoolean(Console.ReadLine());
                            Console.WriteLine("2. Opciones para cambiar la contraseña o configuración de cuenta: ");
                            bool opcion = Convert.ToBoolean(Console.ReadLine());

                            Console.WriteLine($"configuración de notificación: {Configuaracion} y " +
                                $" Opciones para cambiar la contraseña o configuración de cuenta: {opcion} ");

                            Console.WriteLine("¿Desea repetir el menú? (Sí/No): ");
                            string resp5 = Console.ReadLine();

                            if (!resp5.Equals("Sí", StringComparison.OrdinalIgnoreCase))
                            {
                                Rep5 = false;
                            }

                            Console.WriteLine("Menu 6 finalizado, precione enter para continuar.");
                            Console.ReadKey();
                        }
                        break;
                    case 7:
                        salir = true;
                        break;

                }
            }
        }
    }
}
