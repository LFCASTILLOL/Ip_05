﻿// See https://aka.ms/new-console-template for more information

using Proyecto_final_pruebas;

Console.WriteLine("------------------------PROGRAMA RECORDATORIO DE TAREAS, PROYECTOS O OTROS------------------------");
Console.WriteLine("El programa es un recordatorio de diferentes actividades, pidiendo información necesaria para que pueda tener los datos suficientes para generar los recordatorios y establecer cómo por ejemplo hora de recordatorio, prioridad, tipo de recordatorio, etc.");
Console.WriteLine("Precione enter para continuar");
Console.ReadKey();  
Console.Clear();
bool continuar = true; // variable para el while 
while (continuar == true) // repetir el ciclo hasta que que la variable sea falsa
{
    Console.WriteLine("------------------------MENU PRINCIPAL------------------------");
    Console.WriteLine("1. Proceso principal (servicio)\r\n2. Manual de usuario\r\n3. Créditos\r\n4. Salir");
   
    string opc = Convert.ToString(Console.ReadLine());

    switch (opc)
    {
        case "1":
            Menu_principal.Caso1();
            
            break;
        case "2":
            Menu_principal.Caso2();
            break;
        case "3":
            Menu_principal.Caso3();
            break;
        case "4":
            Console.WriteLine("Hasta luego, fin del programa");
            continuar = false; 
            break;
        default:
            Console.WriteLine("Ingrese una opcion correcta.");
            break;

    }
}

class Menu_principal
{
    public static void Caso1()
    {
        MENUPRIN.Menus();
    }
    public static void Caso2()
    {
        Console.Clear();
        Console.WriteLine("I. Listar y explicar todas las opciones que posee programa.\r\nII. Listar los pasos a seguir para mostrar solución de \r\nproblemática.\r\nIII. Explicación detallada de propósito de programa");
        Console.ReadKey();
        Console.Clear();
    }
    public static void Caso3()
    {
        Console.Clear();
        Console.WriteLine("Nombre de proyecto: PROGRAMA RECORDATORIO DE TAREAS, PROYECTOS O OTROS\r\nFecha de creación: 6 de octubre de 2023\r\nHoras invertidas en creación de programa: 8 horas de creación de proyecto \r\nLuis Fernando Castillo López \r\n1205023\r\nIngeniería en informática y sistemas \r\n");
        Console.ReadKey();
        Console.Clear();

    }
}



