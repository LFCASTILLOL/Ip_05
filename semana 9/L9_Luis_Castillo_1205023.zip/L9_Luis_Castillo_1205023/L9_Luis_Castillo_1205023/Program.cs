﻿// See https://aka.ms/new-console-template for more information
using System;

class Program
{
    static void Main()
    {
        double Dmontoc = Menumonto();
        if (Dmontoc < 0)
        {
            Console.WriteLine("Error: Debe ingresar un monto de compra válido.");
            return;
        }

        double descuento = CalcDesc(Dmontoc);
        double MontoP = CalcMonto(Dmontoc, descuento);

        Console.Write("¿Tiene un código de descuento? (S/N): ");
        string tieneCodigo = Console.ReadLine();

        double descuentoAplicado = 0;

        if (tieneCodigo.ToLower() == "s")
        {
            double descuentoAdicional = AplicarDes(MontoP);
            descuentoAplicado += (1 - (MontoP / Dmontoc)) * 100;
            MontoP = descuentoAdicional;
        }

        MontoF(MontoP, descuentoAplicado);
    }

    static double Menumonto()
    {
        Console.Write("Ingrese el monto de la compra: ");
        string entrada = Console.ReadLine();

        if (!double.TryParse(entrada, out double monto))
        {
            Console.WriteLine("Error: Debe ingresar un monto de compra válido.");
            return -1;
        }

        return monto;
    }

    static double CalcDesc(double MontoC)
    {
        double descuento = 0;

        if (MontoC >= 400 && MontoC <= 1000)
        {
            descuento = 0.07;
        }
        else if (MontoC > 1000 && MontoC <= 5000)
        {
            descuento = 0.10;
        }
        else if (MontoC > 5000 && MontoC <= 15000)
        {
            descuento = 0.15;
        }
        else if (MontoC > 15000)
        {
            descuento = 0.25;
        }

        return descuento;
    }

    static double CalcMonto(double MontoC, double descuento)
    {
        return MontoC * (1 - descuento);
    }

    static double AplicarDes(double MontoP)
    {
        double DesA = 0.05;
        return MontoP * (1 - DesA);
    }

    static void MontoF(double MontoP, double DesA)
    {
        Console.WriteLine($"Monto a pagar: {MontoP:F2}");
        Console.WriteLine($"Descuento aplicado: {DesA:F2}%");
        Console.WriteLine($"Valor del descuento: {MontoP - (MontoP / (1 - (DesA / 100))):F2}");
    }
}







