﻿// See https://aka.ms/new-console-template for more information

double USD = 7.83;
double[] CANTIDADES = new double[3];

for (int i = 0; i < 3; i++)
{
    Console.WriteLine($"Ingrese la cantidad No. {i + 1}:");

    double CANT1;
    while (!double.TryParse(Console.ReadLine(), out CANT1))
    {
        Console.WriteLine("Ingrese una cantidad válida.");
    }

    Console.WriteLine("Ingrese la moneda (USD o GTQ):");
    string SCANT1 = Console.ReadLine();

    if (SCANT1 == "USD")
    {
        CANT1 *= USD;
    }
    CANTIDADES[i] = CANT1;
}
Array.Sort(CANTIDADES);

Console.WriteLine("Resultado:");
foreach (double CANT1 in CANTIDADES)
{
    Console.WriteLine($"{CANT1:F2} GTQ");
}
